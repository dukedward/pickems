// src/components/TeamRow.jsx
import React from "react";

function TeamRow({ team, label }) {
    return (
        <div className="team-row">
            <div className="team-info">
                <span className="team-label">{label}</span>
                <span className="team-name">
                    {team.abbrev} · {team.name}
                </span>
            </div>
            <div className="team-score">{team.score}</div>
        </div>
    );
}

export default TeamRow;